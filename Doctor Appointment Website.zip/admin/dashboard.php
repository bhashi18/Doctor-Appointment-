<?php
// Admin Dashboard Panel for eDoc


include("../connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <title>Admin Dashboard</title>
    <style>
        .dashboard-card {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #fff;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            padding: 18px 24px;
            min-width: 240px;
            min-height: 110px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        .dashboard-card-content {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }
        .dashboard-card-number {
            color: #1976d2;
            font-size: 2.2rem;
            font-weight: 600;
            margin-bottom: 2px;
        }
        .dashboard-card-label {
            color: #222;
            font-size: 1.1rem;
            font-weight: 500;
        }
        .dashboard-card-icon {
            background: #f5f6fa;
            border-radius: 8px;
            width: 56px;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .dashboard-card-icon img {
            width: 28px;
            height: 28px;
        }
        .dashboard-cards-row {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }
        /* Style for Recent Appointments and Upcoming Sessions tables */
        .sub-table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
            overflow: hidden;
        }
        .sub-table th, .sub-table td {
            padding: 14px 12px;
            text-align: left;
        }
        .sub-table thead th {
            background: #1976d2;
            color: #fff;
            font-weight: 600;
            border-bottom: 2px solid #e0e0e0;
        }
        .sub-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: background 0.2s;
        }
        .sub-table tbody tr:hover {
            background: #f5f6fa;
        }
        .sub-table tbody td {
            color: #222;
            font-size: 1rem;
        }
        .sub-table tbody tr:last-child {
            border-bottom: none;
        }
        .sub-table td[colspan] {
            text-align: center;
            color: #888;
            font-style: italic;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="menu">
        <table class="menu-container" border="0">
            <tr>
                <td style="padding:10px" colspan="2">
                    <table border="0" class="profile-container">
                        <tr>
                            <td width="30%" style="padding-left:20px" >
                                <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                            </td>
                            <td style="padding:0px;margin:0px;">
                                <p class="profile-title">Administrator</p>
                                <p class="profile-subtitle">admin@edoc.com</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="menu-row" >
                <td class="menu-btn menu-icon-dashbord menu-active menu-icon-dashbord-active" >
                    <a href="dashboard.php" class="non-style-link-menu non-style-link-menu-active">
                        <div>
                            <p class="menu-text">Dashboard</p>
                        </div>
                    </a>
                </td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-doctor ">
                    <a href="doctors.php" class="non-style-link-menu ">
                        <div>
                            <p class="menu-text">Doctors</p>
                        </div>
                    </a>
                </td>
            </tr>
            <tr class="menu-row" >
                <td class="menu-btn menu-icon-schedule">
                    <a href="schedule.php" class="non-style-link-menu">
                        <div>
                            <p class="menu-text">Schedule</p>
                        </div>
                    </a>
                </td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-appoinment">
                    <a href="appointment.php" class="non-style-link-menu">
                        <div>
                            <p class="menu-text">Appointment</p>
                        </div>
                    </a>
                </td>
            </tr>
            <tr class="menu-row" >
                <td class="menu-btn menu-icon-patient">
                    <a href="patient.php" class="non-style-link-menu">
                        <div>
                            <p class="menu-text">Patients</p>
                        </div>
                    </a>
                </td>
            </tr>
        </table>
    </div>
    <div class="dash-body" style="margin-top: 15px">
        <h2 style="margin-left: 30px; color: #161c2d;">Welcome to Admin Dashboard</h2>
        <div style="margin: 30px;">
            <div class="dashboard-cards-row">
                <div class="dashboard-card">
                    <div class="dashboard-card-content">
                        <span class="dashboard-card-number">
                            <?php $doctorrow = $database->query("select * from doctor;"); echo $doctorrow->num_rows; ?>
                        </span>
                        <span class="dashboard-card-label">All Doctors</span>
                    </div>
                    <div class="dashboard-card-icon">
                        <img src="../img/icons/doctors-hover.svg" alt="Doctors">
                    </div>
                </div>
                <div class="dashboard-card">
                    <div class="dashboard-card-content">
                        <span class="dashboard-card-number">
                            <?php $patientrow = $database->query("select * from patient;"); echo $patientrow->num_rows; ?>
                        </span>
                        <span class="dashboard-card-label">All Patients</span>
                    </div>
                    <div class="dashboard-card-icon">
                        <img src="../img/icons/patients-hover.svg" alt="Patients">
                    </div>
                </div>
                <div class="dashboard-card">
                    <div class="dashboard-card-content">
                        <span class="dashboard-card-number">
                            <?php $appointmentrow = $database->query("select * from appointment;"); echo $appointmentrow->num_rows; ?>
                        </span>
                        <span class="dashboard-card-label">All Appointments</span>
                    </div>
                    <div class="dashboard-card-icon">
                        <img src="../img/icons/book-hover.svg" alt="Appointments">
                    </div>
                </div>
            </div>
            <div style="margin-top: 40px;">
                <h3>Recent Appointments</h3>
                <div style="overflow-x:auto;">
                <table class="sub-table" border="1" style="width:100%; background:#fff; border-radius:8px;">
                    <thead>
                        <tr>
                            <th>Appointment No</th>
                            <th>Patient Name</th>
                            <th>Doctor</th>
                            <th>Date</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $database->query("SELECT appointment.apponum, patient.pname, doctor.docname, appointment.appodate, appointment.apptime FROM appointment INNER JOIN patient ON appointment.pid=patient.pid INNER JOIN doctor ON appointment.docid=doctor.docid ORDER BY appointment.appodate DESC, appointment.apptime DESC LIMIT 5");
                        if($result && $result->num_rows > 0){
                            while($row = $result->fetch_assoc()){
                                echo '<tr>';
                                echo '<td>'.$row['apponum'].'</td>';
                                echo '<td>'.$row['pname'].'</td>';
                                echo '<td>'.$row['docname'].'</td>';
                                echo '<td>'.$row['appodate'].'</td>';
                                echo '<td>'.$row['apptime'].'</td>';
                                echo '</tr>';
                            }
                        } else {
                            echo '<tr><td colspan="5" style="text-align:center;">No recent appointments found.</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
                </div>
            </div>
            <div style="margin-top: 40px;">
                <h3>Upcoming Sessions</h3>
                <div style="overflow-x:auto;">
                <table class="sub-table" border="1" style="width:100%; background:#fff; border-radius:8px;">
                    <thead>
                        <tr>
                            <th>Session Title</th>
                            <th>Doctor</th>
                            <th>Date</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $today = date('Y-m-d');
                        $result = $database->query("SELECT schedule.title, doctor.docname, schedule.scheduledate, schedule.scheduletime FROM schedule INNER JOIN doctor ON schedule.docid=doctor.docid WHERE schedule.scheduledate >= '$today' ORDER BY schedule.scheduledate ASC, schedule.scheduletime ASC LIMIT 5");
                        if($result && $result->num_rows > 0){
                            while($row = $result->fetch_assoc()){
                                echo '<tr>';
                                echo '<td>'.$row['title'].'</td>';
                                echo '<td>'.$row['docname'].'</td>';
                                echo '<td>'.$row['scheduledate'].'</td>';
                                echo '<td>'.$row['scheduletime'].'</td>';
                                echo '</tr>';
                            }
                        } else {
                            echo '<tr><td colspan="4" style="text-align:center;">No upcoming sessions found.</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>